<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDustbinlevelsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dustbinlevels', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('dustbin_id')->unsigned();
            $table->integer('level');
            $table->timestamps();
        });


        Schema::table('dustbinlevels', function(Blueprint $table)
        {
            $table->foreign('dustbin_id')->references('id')->on('dustbins')->onDelete('cascade');
        });
    }


        

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dustbinlevels');
    }
}
